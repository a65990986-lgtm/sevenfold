/* 七曜牌局 v1.0.1 — 关卡与 BOSS 权能
 *
 * 关卡 = 一组 BOSS 权能，和「棋力难度」正交：
 *   难度决定墨鸦算得多深，关卡决定墨鸦额外拥有哪些特权。
 *
 * 本版将旧版 13×13 / 七子 / 单牌 的 BOSS 设计，移植到
 * 20×20 / 六子 / 蓝条不限张数的新核心：
 *   - 换营：玩家第 2、4、6… 次连成五子时触发；
 *   - 双术：偶数回合墨鸦蓝条上限 +1（4/4），多出来的蓝可以多打一张 1 费牌。
 */
(function (root, factory) {
  const lib = factory();
  if (typeof module === 'object' && module.exports) module.exports = lib;
  root.SEVENFOLD_LEVELS = lib;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const BOSS_SKILLS = {
    campSwap: {
      id: 'campSwap',
      name: '换营',
      tag: '夺子',
      desc: '你第 2、4、6… 次连成五子时，双方星子归属对调；若墨鸦本已占优，换营不发动。',
      hint: '连五子会喂给墨鸦。真要连，就连在墨鸦也压不住的地方。',
      detail: '只换棋盘上的星子：金身随子走；双生格、策反区、封禁格、手牌、暗牌、六合/五合改命的胜利条件与术式归属都不动。判定只在第 2、4、6… 次五连时进行一次，被「占优」压住的那一次就过去了，要等下一个偶数次。交换后如果墨鸦因此连成六子，当场判胜。'
    },
    doubleCard: {
      id: 'doubleCard',
      name: '双术',
      tag: '连牌',
      desc: '偶数回合（第 2、4、6… 回合）墨鸦蓝条上限 +1（4/4），多出的蓝可以多打一张 1 费牌。',
      hint: '偶数回合要防「即时 + 秘式」的组合，例如先封禁、再策反。',
      detail: '奇数回合仍是 3/3；玩家不受影响，永远 3/3。新版的蓝条不限制出牌张数，因此把旧版「两个牌位」转译为「额外 1 点蓝」，既保留双术的压迫感，也不破坏蓝条规则。'
    }
  };

  const LEVELS = [
    {
      id: 'basic',
      name: '基础关',
      subtitle: '墨鸦执掌两项权能',
      bossSkills: ['campSwap', 'doubleCard']
    },
    {
      id: 'plain',
      name: '无技能关',
      subtitle: '按原始规则对局',
      bossSkills: []
    }
  ];

  const BY_ID = Object.fromEntries(LEVELS.map(level => [level.id, level]));
  const DEFAULT_LEVEL = 'basic';

  function skillsOf(levelId) {
    const level = BY_ID[levelId];
    if (!level || !level.bossSkills.length) return [];
    return level.bossSkills.map(id => BOSS_SKILLS[id]).filter(Boolean);
  }

  return { LEVELS, BY_ID, BOSS_SKILLS, DEFAULT_LEVEL, skillsOf };
});
