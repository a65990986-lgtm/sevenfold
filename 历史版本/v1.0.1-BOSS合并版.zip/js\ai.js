/* 七曜牌局 — 人机棋手「墨鸦」（蓝条版）
 * 只读取公开信息与自己的暗牌；不会偷看玩家秘式。
 *
 * 蓝条版 AI 的核心变化：
 *   - 一回合可以连续出多张牌，只要蓝条足够；
 *   - 先即时、再落子、最后延时；
 *   - 出牌顺序按「胜点 > 关键强化 > 骚扰 > 余牌」评估。
 */
(function (root, factory) {
  const lib = factory();
  if (typeof module === 'object' && module.exports) module.exports = lib;
  root.SevenfoldAI = lib.AI;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const opposite = side => (side === 'player' ? 'ai' : 'player');
  const DIRS = [[0, 1], [1, 0], [1, 1], [1, -1]];
  const MOVE_DIRS = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]];

  const DIFFICULTY = {
    easy: { noise: 0.38, top: 6, card: 0.38, delayed: 0.35, label: '见习' },
    normal: { noise: 0.08, top: 2, card: 0.72, delayed: 0.62, label: '棋师' },
    hard: { noise: 0.015, top: 1, card: 0.92, delayed: 0.86, label: '大棋士' }
  };

  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0;
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  class AI {
    constructor(engine, options = {}) {
      this.engine = engine;
      this.side = options.side || 'ai';
      this.difficulty = DIFFICULTY[options.difficulty] ? options.difficulty : 'normal';
      this.rng = mulberry32(options.seed ?? ((Date.now() ^ 0x9e3779b9) >>> 0));
      this.planPlacement = null;
      this.scoutedPlayerHand = null;
    }

    get config() { return DIFFICULTY[this.difficulty]; }
    get state() { return this.engine.state; }
    get sideState() { return this.state.players[this.side]; }
    get opponent() { return opposite(this.side); }

    inBounds(r, c) { return this.engine.inBounds(r, c); }
    getStone(r, c) { return this.engine.getStone(r, c); }

    weightOf(stone, r, c) {
      return this.engine.stoneWeight(stone, r, c);
    }

    wouldWinFor(side, r, c, weight = 1, target = 6) {
      if (!this.inBounds(r, c) || this.getStone(r, c)) return false;
      for (const [dr, dc] of DIRS) {
        let total = weight;
        for (const sign of [-1, 1]) {
          let nr = r + dr * sign;
          let nc = c + dc * sign;
          while (this.inBounds(nr, nc)) {
            const stone = this.getStone(nr, nc);
            if (!stone || stone.owner !== side) break;
            total += this.weightOf(stone, nr, nc);
            nr += dr * sign;
            nc += dc * sign;
          }
        }
        if (total >= target) return true;
      }
      return false;
    }

    getImmediateWins(side, target) {
      const t = target ?? this.state.players[side].winTarget;
      const wins = [];
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          if (this.getStone(r, c)) continue;
          if (this.engine.isSealed(r, c)) continue;
          if (this.wouldWinFor(side, r, c, 1, t)) wins.push({ r, c });
        }
      }
      return wins;
    }

    lineWindows(r, c, side, dr, dc, weight, target) {
      const span = target * 2 - 1;
      const center = target - 1;
      const line = [];
      for (let i = 0; i < span; i++) {
        const off = i - center;
        const nr = r + dr * off;
        const nc = c + dc * off;
        if (!this.inBounds(nr, nc)) {
          line.push({ type: 'block' });
        } else if (off === 0) {
          line.push({ type: 'self', weight });
        } else {
          const stone = this.getStone(nr, nc);
          if (!stone) line.push({ type: 'empty' });
          else if (stone.owner === side) line.push({ type: 'self', weight: this.weightOf(stone, nr, nc) });
          else line.push({ type: 'block' });
        }
      }

      let score = 0;
      let bestOwn = 0;
      let near = 0;
      for (let start = 0; start <= target - 1; start++) {
        let own = 0;
        let empty = 0;
        let blocked = false;
        for (let j = start; j < start + target; j++) {
          const cell = line[j];
          if (cell.type === 'block') { blocked = true; break; }
          if (cell.type === 'self') own += cell.weight;
          else empty++;
        }
        if (blocked) continue;
        bestOwn = Math.max(bestOwn, own);
        if (own >= target - 2) near++;
        score += this.windowValue(own, empty, target);
      }
      return { score, bestOwn, near };
    }

    windowValue(own, empty, target) {
      const gap = target - own;
      if (gap <= 0) return 2400000;
      if (gap === 1) return 130000;
      if (gap === 2) return 9000;
      if (gap === 3) return 620;
      if (gap === 4) return 48;
      return own * own * 2 + empty;
    }

    scoreCell(r, c, side, weight = 1) {
      if (!this.inBounds(r, c) || this.getStone(r, c)) return { score: -Infinity };
      if (this.engine.isSealed(r, c)) return { score: -Infinity };
      const actor = side;
      const opp = opposite(side);
      const actorTarget = this.state.players[side].winTarget;
      const oppTarget = this.state.players[opp].winTarget;

      if (this.wouldWinFor(actor, r, c, weight, actorTarget)) {
        return { score: 1e9, win: true, attack: 1e9, defense: 0, threats: 4, best: null };
      }

      let attack = 0;
      let defense = 0;
      let threatDirs = 0;
      let best = { bestOwn: 0, dir: DIRS[0] };

      for (const [dr, dc] of DIRS) {
        const atk = this.lineWindows(r, c, actor, dr, dc, weight, actorTarget);
        attack += atk.score;
        if (atk.bestOwn >= actorTarget - 2) threatDirs++;
        if (atk.bestOwn > best.bestOwn) best = { bestOwn: atk.bestOwn, dir: [dr, dc], near: atk.near };

        const def = this.lineWindows(r, c, opp, dr, dc, 1, oppTarget);
        defense += def.score;
        if (def.bestOwn >= oppTarget - 1) defense += 260000;
      }

      if (this.wouldWinFor(opp, r, c, 1, oppTarget)) defense += 3e8;

      let bonus = 0;
      const center = (this.state.size - 1) / 2;
      const dist = Math.abs(r - center) + Math.abs(c - center);
      bonus += Math.max(0, 12 - dist) * 1.6;
      let neighbors = 0;
      for (let dr = -2; dr <= 2; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
          const stone = this.inBounds(r + dr, c + dc) ? this.getStone(r + dr, c + dc) : null;
          if (stone && stone.owner === actor) neighbors += 2;
          if (stone && stone.owner !== actor) neighbors += 1;
        }
      }
      bonus += neighbors;
      if (threatDirs >= 2) attack += 90000 * (threatDirs - 1);

      return { score: attack * 1.02 + defense * 0.92 + bonus, attack, defense, threats: threatDirs, best, win: false };
    }

    candidateCells() {
      const forced = this.state.forced;
      if (forced && forced.target === this.side) {
        return this.engine.canPlace(this.side, forced.r, forced.c) ? [{ r: forced.r, c: forced.c }] : [];
      }
      const all = this.engine.getPlacementCells(this.side);
      if (!all.length) return [];
      let hasStone = false;
      for (let r = 0; r < this.state.size && !hasStone; r++) {
        for (let c = 0; c < this.state.size; c++) {
          if (this.getStone(r, c)) { hasStone = true; break; }
        }
      }
      if (!hasStone) {
        const mid = Math.floor(this.state.size / 2);
        return [{ r: mid, c: mid }];
      }
      const near = [];
      for (const cell of all) {
        let close = false;
        for (let dr = -2; dr <= 2 && !close; dr++) {
          for (let dc = -2; dc <= 2; dc++) {
            if ((dr || dc) && this.inBounds(cell.r + dr, cell.c + dc) && this.getStone(cell.r + dr, cell.c + dc)) {
              close = true;
              break;
            }
          }
        }
        if (close) near.push(cell);
      }
      return near.length ? near : all;
    }

    rankPlacements() {
      return this.candidateCells().map(cell => ({
        ...cell,
        ...this.scoreCell(cell.r, cell.c, this.side)
      })).sort((a, b) => b.score - a.score);
    }

    choosePlacement() {
      const forced = this.state.forced;
      if (forced && forced.target === this.side) {
        return this.engine.canPlace(this.side, forced.r, forced.c) ? { r: forced.r, c: forced.c } : null;
      }
      const wins = this.getImmediateWins(this.side);
      if (wins.length) return this.pickAmong(wins);
      const rank = this.rankPlacements();
      if (!rank.length) return null;
      const threats = this.getImmediateWins(this.opponent);
      if (threats.length) {
        const blocks = threats
          .filter(t => this.engine.canPlace(this.side, t.r, t.c))
          .map(t => ({ ...t, ...this.scoreCell(t.r, t.c, this.side) }))
          .sort((a, b) => b.score - a.score);
        if (blocks.length) {
          if (this.difficulty === 'easy' && this.rng() < 0.18) return this.pickAmong(rank.slice(0, 3));
          return blocks[0];
        }
      }
      const top = Math.min(this.config.top, rank.length);
      if (this.difficulty === 'easy' || this.difficulty === 'normal') {
        const pickPool = rank.slice(0, Math.max(top, this.difficulty === 'easy' ? 7 : 3));
        const weights = pickPool.map((_, i) => Math.exp(-i / (this.difficulty === 'easy' ? 2.2 : 1.1)));
        const total = weights.reduce((a, b) => a + b, 0);
        let roll = this.rng() * total;
        for (let i = 0; i < pickPool.length; i++) {
          roll -= weights[i];
          if (roll <= 0) return pickPool[i];
        }
        return pickPool[0];
      }
      return rank[0];
    }

    pickAmong(list) {
      return list[Math.floor(this.rng() * list.length)];
    }

    handEntries(type) {
      const p = this.state.players[this.side];
      const seen = new Set();
      return p.hand.filter(entry => {
        const card = this.engine.cardById(entry.id);
        if (!card || card.type !== type || seen.has(card.id)) return false;
        seen.add(card.id);
        return this.engine.canPlayCard(this.side, entry.uid).ok;
      });
    }

    maxLineWeight(side) {
      let best = 0;
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          const stone = this.getStone(r, c);
          if (!stone || stone.owner !== side) continue;
          for (const [dr, dc] of DIRS) {
            const prev = this.getStone(r - dr, c - dc);
            if (prev && prev.owner === side) continue;
            let total = 0;
            let nr = r;
            let nc = c;
            while (this.inBounds(nr, nc)) {
              const item = this.getStone(nr, nc);
              if (!item || item.owner !== side) break;
              total += this.weightOf(item, nr, nc);
              nr += dr;
              nc += dc;
            }
            best = Math.max(best, total);
          }
        }
      }
      return best;
    }

    simulateMoveWin(from, to, side) {
      const stone = this.getStone(from.r, from.c);
      if (!stone) return null;
      this.engine.setStone(from.r, from.c, null);
      this.engine.setStone(to.r, to.c, stone);
      const win = this.engine.findWin(side);
      this.engine.setStone(to.r, to.c, null);
      this.engine.setStone(from.r, from.c, stone);
      return win;
    }

    findWinningMoveCard(cardId) {
      const movers = this.engine.getCardTargets(this.side, cardId);
      const owner = cardId === 'repel' ? this.opponent : this.side;
      for (const from of movers) {
        for (const to of this.engine.getMoveDestinations(from.r, from.c)) {
          const win = this.simulateMoveWin(from, to, owner);
          if (win) return { from: { r: from.r, c: from.c }, to: { r: to.r, c: to.c }, win };
        }
      }
      return null;
    }

    findForkMove(cardId) {
      const movers = this.engine.getCardTargets(this.side, cardId);
      for (const from of movers) {
        const stone = this.getStone(from.r, from.c);
        if (!stone) continue;
        for (const to of this.engine.getMoveDestinations(from.r, from.c)) {
          this.engine.setStone(from.r, from.c, null);
          this.engine.setStone(to.r, to.c, stone);
          const wins = this.getImmediateWins(this.side);
          this.engine.setStone(to.r, to.c, null);
          this.engine.setStone(from.r, from.c, stone);
          if (wins.length >= 2) return { from: { r: from.r, c: from.c }, to: { r: to.r, c: to.c } };
        }
      }
      return null;
    }

    findTwinWinCell() {
      if (this.sideState.mana < 2) return null;
      const target = this.sideState.winTarget;
      for (const cell of this.candidateCells()) {
        if (!this.engine.isSealed(cell.r, cell.c) && this.wouldWinFor(this.side, cell.r, cell.c, 2, target)) {
          return { r: cell.r, c: cell.c, plan: true };
        }
      }
      const keyOf = (r, c) => r + ',' + c;
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          const stone = this.getStone(r, c);
          if (!stone || stone.owner !== this.side) continue;
          if (this.engine.isDoubleCell(r, c, this.side)) continue;
          this.state.doubleCells[keyOf(r, c)] = {
            owner: this.side,
            r, c,
            expiresPly: this.state.ply + 6
          };
          const win = this.engine.findWin(this.side);
          delete this.state.doubleCells[keyOf(r, c)];
          if (win) return { r, c, plan: false };
        }
      }
      return null;
    }

    pickTwinStrategic(blockOnly = false) {
      const cell = this.findTwinWinCell();
      if (cell) {
        if (cell.plan) this.planPlacement = { r: cell.r, c: cell.c };
        return cell;
      }
      if (blockOnly) return null;
      // 非必胜时，把双生格放在己方最长线的关键格上，或放在最佳落点。
      const rank = this.rankPlacements();
      if (!rank.length) return null;
      const best = rank[0];
      if (best.score > 5000 || this.rng() < 0.28) {
        this.planPlacement = { r: best.r, c: best.c };
        return { r: best.r, c: best.c, plan: true };
      }
      return null;
    }

    pickInstant() {
      const entries = this.handEntries('instant');
      if (!entries.length) return null;
      const byId = id => entries.find(entry => entry.id === id);
      const aiWins = this.getImmediateWins(this.side);
      if (aiWins.length) return null;

      const playerWins = this.getImmediateWins(this.opponent);
      const shift = byId('shift');
      if (shift) {
        const winning = this.findWinningMoveCard('shift');
        if (winning) return { entry: shift, payload: { from: winning.from, to: winning.to } };
        if (!playerWins.length) {
          const fork = this.findForkMove('shift');
          if (fork && this.rng() < 0.65) return { entry: shift, payload: fork };
        }
      }

      const twin = byId('twin');
      if (twin) {
        const spot = this.pickTwinStrategic(playerWins.length > 0);
        if (spot) return { entry: twin, payload: { r: spot.r, c: spot.c } };
      }

      const rank = this.rankPlacements();
      const best = rank[0];
      const canSpend = !playerWins.length && this.rng() < this.config.card;
      if (!canSpend) return null;

      const ruin = byId('ruin');
      if (ruin) {
        const center = this.pickRuinCenter();
        if (center) {
          this.planPlacement = center;
          return { entry: ruin, payload: {} };
        }
      }

      const sealOrtho = byId('sealOrtho');
      const sealDiag = byId('sealDiag');
      if (best && (sealOrtho || sealDiag)) {
        const playerMax = this.maxLineWeight(this.opponent);
        const playerBest = playerMax >= 4 ? this.bestPlayerCell() : null;
        const pressured = best.threats >= 2 || (playerMax >= 4 && best.threats >= 1);
        if (pressured && this.rng() < 0.6) {
          const dir = playerBest && playerBest.best ? playerBest.best.dir : null;
          const diagonal = !!dir && dir[0] !== 0 && dir[1] !== 0;
          const entry = diagonal ? (sealDiag || sealOrtho) : (sealOrtho || sealDiag);
          this.planPlacement = { r: best.r, c: best.c };
          return { entry, payload: {} };
        }
      }

      const scout = byId('scout');
      if (scout && this.rng() < 0.32) return { entry: scout, payload: {} };

      const repel = byId('repel');
      if (repel && !playerWins.length && this.rng() < 0.2) {
        const disruption = this.pickRepel();
        if (disruption) return { entry: repel, payload: disruption };
      }

      const expand = byId('expand');
      if (expand && this.state.size < this.engine.rules.maxSize && this.rng() < 0.09) {
        return { entry: expand, payload: {} };
      }

      return null;
    }

    pickRuinCenter() {
      let best = null;
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          if (this.getStone(r, c) || this.engine.isSealed(r, c)) continue;
          let playerStones = 0;
          let aiStones = 0;
          let weighted = 0;
          for (let dr = -1; dr <= 1; dr++) {
            for (let dc = -1; dc <= 1; dc++) {
              const stone = this.inBounds(r + dr, c + dc) ? this.getStone(r + dr, c + dc) : null;
              if (!stone) continue;
              if (stone.owner === this.opponent) {
                playerStones++;
                weighted += this.weightOf(stone, r + dr, c + dc);
              } else {
                aiStones++;
                weighted -= this.weightOf(stone, r + dr, c + dc);
              }
            }
          }
          if (playerStones < 3) continue;
          const score = playerStones * 100 + weighted * 22 - aiStones * 145;
          if (!best || score > best.score) best = { r, c, score, playerStones, aiStones };
        }
      }
      if (!best) return null;
      const threshold = this.difficulty === 'hard' ? 260 : 360;
      return best.score >= threshold ? { r: best.r, c: best.c } : null;
    }

    pickRepel() {
      let best = null;
      for (const from of this.engine.getCardTargets(this.side, 'repel')) {
        const stone = this.getStone(from.r, from.c);
        if (!stone) continue;
        let local = 0;
        for (const [dr, dc] of DIRS) {
          let run = 1;
          for (const sign of [-1, 1]) {
            let nr = from.r + dr * sign;
            let nc = from.c + dc * sign;
            while (this.inBounds(nr, nc)) {
              const item = this.getStone(nr, nc);
              if (!item || item.owner !== this.opponent) break;
              run++;
              nr += dr * sign;
              nc += dc * sign;
            }
          }
          local = Math.max(local, run);
        }
        for (const to of this.engine.getMoveDestinations(from.r, from.c)) {
          const center = (this.state.size - 1) / 2;
          const score = local * 100 - (Math.abs(to.r - center) + Math.abs(to.c - center)) * 2;
          if (local >= 4 && (!best || score > best.score)) {
            best = { from: { r: from.r, c: from.c }, to: { r: to.r, c: to.c }, score };
          }
        }
      }
      return best ? { from: best.from, to: best.to } : null;
    }

    bestPlayerCell() {
      const rank = this.rankPlacementsFor(this.opponent);
      return rank[0] || null;
    }

    rankPlacementsFor(side) {
      const list = [];
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          if (this.getStone(r, c) || this.engine.isSealed(r, c)) continue;
          if (this.state.forced && this.state.forced.target === side) continue;
          list.push({ r, c, ...this.scoreCell(r, c, side) });
        }
      }
      return list.sort((a, b) => b.score - a.score);
    }

    pickDelayed() {
      const entries = this.handEntries('delayed');
      if (!entries.length || this.rng() > this.config.delayed) return null;
      const byId = id => entries.find(entry => entry.id === id);

      const five = byId('fivefold');
      if (five && this.sideState.winTarget === 6) {
        const maxRun = this.maxLineWeight(this.side);
        if (maxRun >= 5 || (maxRun >= 4 && this.rng() < 0.55) || this.rng() < 0.2) {
          return { entry: five, payload: {} };
        }
      }

      const subvert = byId('subvert');
      if (subvert) {
        const best = this.bestPlayerCell();
        if (best && (best.score > 900 || this.rng() < 0.42)) {
          return { entry: subvert, payload: { r: best.r, c: best.c } };
        }
      }

      const silence = byId('silence');
      if (silence && this.state.players[this.opponent].hand.length >= 3 && this.rng() < 0.62) {
        return { entry: silence, payload: {} };
      }

      const foretell = byId('foretell');
      if (foretell && this.sideState.hand.length < this.engine.rules.handLimit && this.rng() < 0.55) {
        return { entry: foretell, payload: {} };
      }

      const aegis = byId('aegis');
      if (aegis) {
        const target = this.bestOwnStone();
        if (target && this.rng() < 0.5) return { entry: aegis, payload: target };
      }

      const mirror = byId('mirror');
      if (mirror && this.state.lastPlaced[this.side] && this.rng() < 0.38) {
        return { entry: mirror, payload: {} };
      }

      return null;
    }

    bestOwnStone() {
      let best = null;
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          const stone = this.getStone(r, c);
          if (!stone || stone.owner !== this.side || stone.shieldUntil > this.state.ply) continue;
          let adjacent = 0;
          for (const [dr, dc] of DIRS) {
            for (const sign of [-1, 1]) {
              const item = this.getStone(r + dr * sign, c + dc * sign);
              if (item && item.owner === this.side) adjacent += 1;
            }
          }
          const center = 12 - (Math.abs(r - (this.state.size - 1) / 2) + Math.abs(c - (this.state.size - 1) / 2));
          const score = adjacent * 12 + center;
          if (!best || score > best.score) best = { r, c, score };
        }
      }
      return best ? { r: best.r, c: best.c } : null;
    }

    async takeTurn(options = {}) {
      const sleep = options.sleep || (ms => new Promise(resolve => setTimeout(resolve, ms)));
      const e = this.engine;
      if (e.state.status !== 'playing' || e.state.current !== this.side) return;
      this.planPlacement = null;
      await sleep(380);
      if (e.state.status !== 'playing' || e.state.current !== this.side) return;

      let guard = 0;
      while (e.state.status === 'playing' && e.state.phase === 'main' && guard++ < 8) {
        const choice = this.pickInstant();
        if (!choice) break;
        const result = e.playCard(this.side, choice.entry.uid, choice.payload);
        await sleep(300);
        if (e.state.status !== 'playing') return;
        if (!result.ok) { this.planPlacement = null; break; }
        if (result.scouted) this.scoutedPlayerHand = result.scouted;
        if (result.expanded && this.planPlacement) {
          this.planPlacement = { r: this.planPlacement.r + 1, c: this.planPlacement.c + 1 };
        }
        if (e.state.phase === 'post') break;
      }

      if (e.state.status === 'playing' && e.state.phase === 'main') {
        let pos = this.planPlacement;
        if (pos && !e.canPlace(this.side, pos.r, pos.c)) pos = null;
        pos = pos || this.choosePlacement();
        if (pos) {
          e.place(this.side, pos.r, pos.c);
          await sleep(360);
          if (e.state.status !== 'playing') return;
        }
      }

      guard = 0;
      while (e.state.status === 'playing' && e.state.phase === 'post' && this.sideState.mana > 0 && guard++ < 8) {
        const delayed = this.pickDelayed();
        if (!delayed) break;
        const result = e.playCard(this.side, delayed.entry.uid, delayed.payload);
        await sleep(300);
        if (e.state.status !== 'playing') return;
        if (!result.ok) break;
      }

      if (e.state.status === 'playing' && e.state.phase === 'post') {
        e.endTurn(this.side);
      }
    }
  }

  return { AI, DIFFICULTY };
});
