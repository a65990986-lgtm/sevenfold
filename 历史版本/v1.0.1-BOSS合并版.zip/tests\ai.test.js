/* 七曜牌局 — 蓝条版人机回归测试
 * 运行：node tests/ai.test.js
 */
'use strict';

const assert = require('assert');
const { Engine } = require('../js/engine.js');
const { AI } = require('../js/ai.js');

let passed = 0;
let failed = 0;
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

function fresh(seed = 7) {
  const e = new Engine({ seed });
  for (const side of ['player', 'ai']) {
    const p = e.state.players[side];
    p.hand = [];
    p.deck = [];
    p.discard = [];
    p.secrets = [];
    p.auras = [];
    p.silenced = false;
    p.winTarget = e.rules.winLength;
    p.mana = e.rules.maxMana;
  }
  e.state.phase = 'main';
  e.state.current = 'ai';
  e.state.status = 'playing';
  e.state.cardsPlayedThisTurn = 0;
  e.state.placed = false;
  e.state.skipPlace = false;
  e.state.moved = false;
  e.state.forced = null;
  e.state.seals = {};
  e.state.zones = [];
  e.state.doubleCells = {};
  e.state.lastPlaced = { player: null, ai: null };
  return e;
}

function put(e, side, r, c, options = {}) {
  const stone = {
    uid: 'stone-' + (++e.uid),
    owner: side,
    doubled: !!options.doubled,
    shieldUntil: options.shieldUntil || 0,
    placedPly: e.state.ply
  };
  e.state.cells[r][c] = stone;
  return stone;
}

function give(e, side, cardId) {
  const entry = { uid: 'test-' + (++e.uid), id: cardId };
  e.state.players[side].hand.push(entry);
  return entry;
}

function makeAI(e, options = {}) {
  return new AI(e, { side: 'ai', difficulty: 'hard', seed: 12345, ...options });
}

test('有一步制胜点时直接落子', () => {
  const e = fresh();
  for (let c = 3; c <= 7; c++) put(e, 'ai', 10, c); // 五连，落 (10,8) 成六
  const ai = makeAI(e);
  const move = ai.choosePlacement();
  assert.ok(move);
  assert.ok(e.wouldWinAt(move.r, move.c, 'ai'), `落点 ${move.r},${move.c} 应该赢`);
});

test('对方下一步能赢时必须挡', () => {
  const e = fresh();
  for (let c = 3; c <= 7; c++) put(e, 'player', 10, c);
  put(e, 'ai', 10, 2);
  const ai = makeAI(e);
  const move = ai.choosePlacement();
  assert.deepStrictEqual({ r: move.r, c: move.c }, { r: 10, c: 8 });
});

test('能识别玩家双生格造成的下一步胜点', () => {
  const e = fresh();
  for (let c = 3; c <= 6; c++) put(e, 'player', 10, c); // 四连 + 双生格，落点权重 5? 
  put(e, 'ai', 10, 2);
  e.state.doubleCells['10,7'] = { owner: 'player', r: 10, c: 7, expiresPly: 99, createdPly: 0 };
  // 四连 + 双生格 = 5，还不是 6；在 10,7 落子是 5，不足以立即赢。
  // 再补一子到五连，双生格点就构成 6。
  put(e, 'player', 10, 8);
  e.state.doubleCells['10,7'] = { owner: 'player', r: 10, c: 7, expiresPly: 99, createdPly: 0 };
  const ai = makeAI(e);
  const wins = ai.getImmediateWins('player');
  assert.ok(wins.some(w => w.r === 10 && w.c === 7), '双生格上的落点应被识别为胜点');
  const move = ai.choosePlacement();
  assert.deepStrictEqual({ r: move.r, c: move.c }, { r: 10, c: 7 });
});

test('对方有杀时，不用位移牌跳过落子', () => {
  const e = fresh();
  for (let c = 3; c <= 8; c++) put(e, 'player', 10, c);
  put(e, 'ai', 10, 2);
  put(e, 'ai', 8, 8);
  give(e, 'ai', 'shift');
  const ai = makeAI(e);
  ai.rng = () => 0;
  ai.findForkMove = () => ({ from: { r: 8, c: 8 }, to: { r: 8, c: 9 } });
  const choice = ai.pickInstant();
  assert.ok(!choice || choice.entry.id !== 'shift');
});

test('takeTurn 可以在一回合内打出多张牌并结束回合', async () => {
  const e = fresh(99);
  for (let c = 4; c <= 7; c++) put(e, 'ai', 10, c);
  for (let c = 4; c <= 7; c++) put(e, 'player', 11, c);
  for (const id of ['twin', 'sealOrtho', 'scout', 'foretell', 'silence']) give(e, 'ai', id);
  e.state.players.ai.deck = [{ uid: 'd1', id: 'aegis' }, { uid: 'd2', id: 'mirror' }];
  const ai = makeAI(e);
  ai.rng = () => 0;
  await ai.takeTurn({ sleep: () => Promise.resolve() });
  assert.ok(e.state.status !== 'playing' || e.state.current === 'player');
  assert.ok(e.state.stats.cardsPlayed >= 2, `应至少打出两张牌，实际 ${e.state.stats.cardsPlayed}`);
});

test('不会打出蓝量不足的牌', () => {
  const e = fresh();
  e.state.players.ai.mana = 1;
  give(e, 'ai', 'ruin'); // 2 费
  give(e, 'ai', 'scout'); // 1 费
  const ai = makeAI(e);
  ai.rng = () => 0;
  const choice = ai.pickInstant();
  assert.ok(!choice || choice.entry.id !== 'ruin');
});

test('AI 会使用预知并在下一回合获得临时牌', async () => {
  const e = fresh(777);
  put(e, 'ai', 10, 10);
  e.state.phase = 'post';
  e.state.current = 'ai';
  e.state.lastPlaced.ai = '10,10';
  give(e, 'ai', 'foretell');
  e.state.players.ai.deck = [
    { uid: 'd1', id: 'scout' }, { uid: 'd2', id: 'sealOrtho' },
    { uid: 'd3', id: 'twin' }, { uid: 'd4', id: 'ruin' }
  ];
  const ai = makeAI(e);
  ai.rng = () => 0;
  e.state.round = 1;
  // 只调用决策，不真正结束回合，避免另一个 AI 接管。
  const choice = ai.pickDelayed();
  assert.ok(choice && ['foretell', 'silence', 'aegis', 'mirror', 'subvert', 'fivefold'].includes(choice.entry.id));
});

(async () => {
  for (const t of tests) {
    try {
      await t.fn();
      passed++;
      console.log(`  ✓ ${t.name}`);
    } catch (err) {
      failed++;
      console.error(`  ✗ ${t.name}`);
      console.error(`    ${err.message}`);
    }
  }
  console.log('');
  console.log(`结果：${passed} 通过，${failed} 失败`);
  process.exit(failed ? 1 : 0);
})();
