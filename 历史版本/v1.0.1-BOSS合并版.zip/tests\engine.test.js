/* 七曜牌局 — 蓝条版规则测试
 * 运行：node tests/engine.test.js
 */
'use strict';

const assert = require('assert');
const { Engine } = require('../js/engine.js');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (err) {
    failed++;
    console.error(`  ✗ ${name}`);
    console.error(`    ${err.message}`);
  }
}

function fresh(seed = 7, options = {}) {
  const e = new Engine({ seed, ...options });
  for (const side of ['player', 'ai']) {
    const p = e.state.players[side];
    p.hand = [];
    p.deck = [];
    p.discard = [];
    p.secrets = [];
    p.auras = [];
    p.silenced = false;
    p.winTarget = e.rules.winLength;
    p.mana = e.rules.maxMana;
  }
  e.state.phase = 'main';
  e.state.current = 'player';
  e.state.status = 'playing';
  e.state.cardsPlayedThisTurn = 0;
  e.state.placed = false;
  e.state.skipPlace = false;
  e.state.moved = false;
  e.state.forced = null;
  e.state.seals = {};
  e.state.zones = [];
  e.state.doubleCells = {};
  e.state.lastPlaced = { player: null, ai: null };
  e.state.lastMove = null;
  return e;
}

function give(e, side, cardId, options = {}) {
  const entry = { uid: 'test-' + (++e.uid), id: cardId, ...options };
  e.state.players[side].hand.push(entry);
  return entry;
}

function put(e, side, r, c, options = {}) {
  const stone = {
    uid: 'stone-' + (++e.uid),
    owner: side,
    doubled: !!options.doubled,
    shieldUntil: options.shieldUntil || 0,
    placedPly: e.state.ply
  };
  e.state.cells[r][c] = stone;
  return stone;
}

function setTurn(e, side, phase = 'main') {
  e.state.current = side;
  e.state.phase = phase;
  e.state.status = 'playing';
  e.state.cardsPlayedThisTurn = 0;
  e.state.placed = phase === 'post';
  e.state.moved = false;
  e.state.skipPlace = false;
}

function addDeck(e, side, ids) {
  const p = e.state.players[side];
  for (const id of ids) p.deck.push({ uid: 'deck-' + (++e.uid), id });
}

console.log('\n七曜牌局 · 蓝条版引擎测试\n');

test('开局为 20×20、六子胜利、7 手牌、3 蓝', () => {
  const e = new Engine({ seed: 1 });
  assert.strictEqual(e.state.size, 20);
  assert.strictEqual(e.state.players.player.winTarget, 6);
  assert.strictEqual(e.state.players.player.hand.length, 9); // 起手 7 + 首回合抽 2
  assert.strictEqual(e.state.players.player.mana, 3);
  assert.strictEqual(e.state.players.player.maxMana, 3);
  assert.strictEqual(e.state.players.ai.hand.length, 7);
});

test('六子连珠立即获胜', () => {
  const e = fresh();
  for (let c = 0; c < 5; c++) put(e, 'player', 10, c);
  const result = e.place('player', 10, 5);
  assert.strictEqual(result.ok, true);
  assert.strictEqual(e.state.status, 'over');
  assert.strictEqual(e.state.winner, 'player');
  assert.strictEqual(e.state.winLine.cells.length, 6);
});

test('蓝条限制出牌张数，而不是每回合 1 张', () => {
  const e = fresh();
  const a = give(e, 'player', 'sealOrtho'); // 1
  const b = give(e, 'player', 'scout');     // 1
  const c = give(e, 'player', 'ruin');      // 2
  assert.strictEqual(e.playCard('player', a.uid).ok, true);
  assert.strictEqual(e.state.players.player.mana, 2);
  assert.strictEqual(e.playCard('player', b.uid).ok, true);
  assert.strictEqual(e.state.players.player.mana, 1);
  const blocked = e.canPlayCard('player', c.uid);
  assert.strictEqual(blocked.ok, false);
  assert.match(blocked.reason, /蓝量不足/);
  assert.strictEqual(e.playCard('player', c.uid).ok, false);
  assert.strictEqual(e.state.players.player.mana, 1);
  assert.strictEqual(e.place('player', 10, 10).ok, true);
  assert.strictEqual(e.state.phase, 'post');
});

test('位移牌使用后不能落子，但仍可进入秘式阶段', () => {
  const e = fresh();
  const a = give(e, 'player', 'repel');
  const b = give(e, 'player', 'shift');
  put(e, 'ai', 10, 10);
  put(e, 'player', 10, 12);
  assert.strictEqual(e.playCard('player', a.uid, {
    from: { r: 10, c: 10 }, to: { r: 9, c: 10 }
  }).ok, true);
  assert.strictEqual(e.state.phase, 'post');
  assert.strictEqual(e.canPlayCard('player', b.uid).ok, false);
  assert.strictEqual(e.state.players.player.mana, 3);
});

test('双生格让己方星子按 2 枚计算，并在 3 回合后失效', () => {
  const e = fresh();
  const twin = give(e, 'player', 'twin');
  assert.strictEqual(e.playCard('player', twin.uid, { r: 10, c: 10 }).ok, true);
  assert.strictEqual(e.state.players.player.mana, 1);
  e.place('player', 10, 10);
  const stone = e.getStone(10, 10);
  assert.strictEqual(e.stoneWeight(stone, 10, 10), 2);
  e.state.ply = 6;
  assert.strictEqual(e.stoneWeight(stone, 10, 10), 1);
});

test('双生格可用于已有己方星子并直接完成胜利', () => {
  const e = fresh();
  for (let c = 0; c < 5; c++) put(e, 'player', 10, c);
  const twin = give(e, 'player', 'twin');
  assert.strictEqual(e.playCard('player', twin.uid, { r: 10, c: 4 }).ok, true);
  assert.strictEqual(e.state.status, 'over');
  assert.strictEqual(e.state.winner, 'player');
});

test('五合改命在使用后第二回合开始生效为 5 子', () => {
  const e = fresh();
  setTurn(e, 'player', 'post');
  const card = give(e, 'player', 'fivefold');
  assert.strictEqual(e.playCard('player', card.uid).ok, true);
  const secret = e.state.players.player.secrets.find(s => s.cardId === 'fivefold');
  assert.strictEqual(secret.activateRound, 3);

  e.state.round = 2;
  e.state.ply = 2;
  e.startTurn('player');
  assert.strictEqual(e.state.players.player.winTarget, 6);

  e.state.round = 3;
  e.state.ply = 4;
  e.startTurn('player');
  assert.strictEqual(e.state.players.player.winTarget, 5);
  assert.strictEqual(e.state.players.player.secrets.some(s => s.cardId === 'fivefold'), false);
});

test('窥星返回对手当前手牌快照', () => {
  const e = fresh();
  put(e, 'ai', 3, 3);
  const a = give(e, 'ai', 'twin');
  const b = give(e, 'ai', 'aegis');
  setTurn(e, 'player');
  const scout = give(e, 'player', 'scout');
  const result = e.playCard('player', scout.uid);
  assert.strictEqual(result.ok, true);
  assert.strictEqual(result.scouted.length, 2);
  assert.deepStrictEqual(result.scouted.map(x => x.id).sort(), [a.id, b.id].sort());
  assert.strictEqual(e.state.players.player.scouted.cards.length, 2);
});

test('预知在下一回合抽 2 张临时牌，并在回合结束销毁', () => {
  const e = fresh();
  addDeck(e, 'player', ['scout', 'sealOrtho', 'twin', 'ruin']);
  setTurn(e, 'player', 'post');
  const fore = give(e, 'player', 'foretell');
  assert.strictEqual(e.playCard('player', fore.uid).ok, true);

  e.state.ply = 2;
  e.state.round = 2;
  e.startTurn('player');
  const temp = e.state.players.player.hand.filter(x => x.temp);
  assert.strictEqual(temp.length, 2);
  setTurn(e, 'player', 'post');
  e.endTurn('player');
  assert.strictEqual(e.state.players.player.hand.filter(x => x.temp).length, 0);
});

test('临时牌被使用后不会回到弃牌堆', () => {
  const e = fresh();
  e.state.players.player.deck = [];
  e.state.players.player.discard = [];
  setTurn(e, 'player', 'main');
  const temp = give(e, 'player', 'scout', { temp: true });
  assert.strictEqual(e.playCard('player', temp.uid).ok, true);
  assert.strictEqual(e.state.players.player.discard.some(x => x.uid === temp.uid), false);
});

test('拓界把星盘从 20 扩到 22，并平移双生格', () => {
  const e = fresh();
  put(e, 'player', 10, 10);
  e.state.lastPlaced.player = '10,10';
  const twin = give(e, 'player', 'twin');
  e.playCard('player', twin.uid, { r: 10, c: 10 });
  const expand = give(e, 'player', 'expand');
  const result = e.playCard('player', expand.uid);
  assert.strictEqual(result.ok, true);
  assert.strictEqual(e.state.size, 22);
  assert.strictEqual(e.getStone(11, 11).owner, 'player');
  assert.ok(e.state.doubleCells['11,11']);
  assert.strictEqual(e.state.doubleCells['10,10'], undefined);
});

test('四方封与崩星可以叠加在下一子上', () => {
  const e = fresh();
  put(e, 'player', 9, 9);
  const seal = give(e, 'player', 'sealOrtho');
  const ruin = give(e, 'player', 'ruin');
  assert.strictEqual(e.playCard('player', seal.uid).ok, true);
  assert.strictEqual(e.playCard('player', ruin.uid).ok, true);
  const result = e.place('player', 10, 10);
  assert.strictEqual(result.ok, true);
  assert.strictEqual(e.getStone(10, 10), null);
  assert.strictEqual(e.isSealed(9, 10), true);
});

test('八向移动：逐客令/挪星步可斜向移动一格', () => {
  const e = fresh();
  put(e, 'player', 10, 10);
  assert.strictEqual(e.getMoveDestinations(10, 10).length, 8);
  const shift = give(e, 'player', 'shift');
  const result = e.playCard('player', shift.uid, {
    from: { r: 10, c: 10 }, to: { r: 9, c: 9 }
  });
  assert.strictEqual(result.ok, true);
  assert.strictEqual(e.getStone(9, 9).owner, 'player');
  assert.strictEqual(e.state.phase, 'post');
});

test('金身阻止敌方位移与爆裂', () => {
  const e = fresh();
  put(e, 'player', 10, 10);
  e.state.lastPlaced.player = '10,10';
  setTurn(e, 'player', 'post');
  const aegis = give(e, 'player', 'aegis');
  assert.strictEqual(e.playCard('player', aegis.uid, { r: 10, c: 10 }).ok, true);
  assert.ok(e.getStone(10, 10).shieldUntil > e.state.ply);

  setTurn(e, 'ai');
  give(e, 'ai', 'repel');
  assert.strictEqual(e.getCardTargets('ai', 'repel').length, 0);
  e.state.players.ai.auras = [{ type: 'ruin', createdPly: 0 }];
  e.place('ai', 9, 10);
  assert.strictEqual(e.getStone(10, 10).owner, 'player');
});

test('换影交换对方新子与锚点', () => {
  const e = fresh();
  put(e, 'player', 10, 9);
  e.state.lastPlaced.player = '10,9';
  setTurn(e, 'player', 'post');
  const mirror = give(e, 'player', 'mirror');
  assert.strictEqual(e.playCard('player', mirror.uid).ok, true);
  assert.strictEqual(e.state.players.player.secrets.length, 1);

  setTurn(e, 'ai');
  assert.strictEqual(e.place('ai', 11, 11).ok, true);
  assert.strictEqual(e.getStone(11, 11).owner, 'player');
  assert.strictEqual(e.getStone(10, 9).owner, 'ai');
});

test('噤声使对方下一张牌失效，但仍消耗蓝量', () => {
  const e = fresh();
  setTurn(e, 'player', 'post');
  const silence = give(e, 'player', 'silence');
  assert.strictEqual(e.playCard('player', silence.uid).ok, true);

  setTurn(e, 'ai');
  const twin = give(e, 'ai', 'twin');
  const result = e.playCard('ai', twin.uid, { r: 10, c: 10 });
  assert.strictEqual(result.ok, true);
  assert.strictEqual(result.nullified, true);
  assert.strictEqual(e.state.players.ai.mana, 1);
  assert.strictEqual(e.state.doubleCells['10,10'], undefined);
  assert.strictEqual(e.state.players.ai.hand.length, 0);
});

test('策反将对方落入 3×3 的星子转为我方', () => {
  const e = fresh();
  setTurn(e, 'player', 'post');
  const subvert = give(e, 'player', 'subvert');
  assert.strictEqual(e.playCard('player', subvert.uid, { r: 10, c: 10 }).ok, true);
  assert.strictEqual(e.state.zones.length, 1);

  setTurn(e, 'ai');
  assert.strictEqual(e.place('ai', 10, 11).ok, true);
  assert.strictEqual(e.getStone(10, 11).owner, 'player');
  assert.strictEqual(e.state.zones.length, 0);
});

test('最终卡在基础版锁定', () => {
  const e = fresh();
  const card = give(e, 'player', 'finalPin');
  const check = e.canPlayCard('player', card.uid);
  assert.strictEqual(check.ok, false);
  assert.match(check.reason, /最终卡/);
});

test('手牌上限为 12，普通抽牌会弃置超出的牌', () => {
  const e = fresh();
  for (let i = 0; i < 12; i++) give(e, 'player', 'sealOrtho');
  e.state.players.player.deck = [{ uid: 'extra', id: 'scout' }];
  e.draw('player', 1);
  assert.strictEqual(e.state.players.player.hand.length, 12);
  assert.strictEqual(e.state.players.player.discard.length, 1);
});

test('牌库耗尽时洗回弃牌堆', () => {
  const e = fresh();
  e.state.players.player.deck = [];
  e.state.players.player.discard = [
    { uid: 'd1', id: 'twin' },
    { uid: 'd2', id: 'ruin' }
  ];
  const drawn = e.draw('player', 1);
  assert.strictEqual(drawn.length, 1);
  assert.strictEqual(e.state.players.player.hand.length, 1);
  assert.strictEqual(e.state.players.player.deck.length, 1);
});

test('新回合回满蓝条并抽 2 张', () => {
  const e = fresh();
  addDeck(e, 'player', ['scout', 'sealOrtho', 'twin']);
  e.state.players.player.mana = 0;
  e.state.players.player.hand = [];
  e.startTurn('player');
  assert.strictEqual(e.state.players.player.mana, 3);
  assert.strictEqual(e.state.players.player.hand.length, 2);
});

test('BOSS 双术：偶数回合墨鸦蓝条上限 4，奇数回合回到 3', () => {
  const e = new Engine({ seed: 77, bossSkills: ['doubleCard'] });
  e.state.ply = 2; // round 2
  e.startTurn('ai');
  assert.strictEqual(e.state.round, 2);
  assert.strictEqual(e.state.players.ai.maxMana, 4);
  assert.strictEqual(e.state.players.ai.mana, 4);

  e.state.ply = 4; // round 3
  e.startTurn('ai');
  assert.strictEqual(e.state.round, 3);
  assert.strictEqual(e.state.players.ai.maxMana, 3);

  e.state.ply = 2; // round 2，玩家不受影响
  e.startTurn('player');
  assert.strictEqual(e.state.players.player.maxMana, 3);
});

test('BOSS 换营：玩家第 2 次连成五子时双方星子易主', () => {
  const e = fresh(88, { bossSkills: ['campSwap'] });
  setTurn(e, 'player');
  for (let c = 1; c <= 4; c++) put(e, 'player', 2, c);
  e.place('player', 2, 5);
  assert.strictEqual(e.state.campSwapCount, 1);
  assert.strictEqual(e.state.campSwaps, 0);
  assert.strictEqual(e.getStone(2, 5).owner, 'player');

  setTurn(e, 'player');
  for (let c = 1; c <= 4; c++) put(e, 'player', 9, c);
  e.place('player', 9, 5);
  assert.strictEqual(e.state.campSwapCount, 2);
  assert.strictEqual(e.state.campSwaps, 1);
  assert.strictEqual(e.getStone(2, 5).owner, 'ai');
  assert.strictEqual(e.getStone(9, 5).owner, 'ai');
});

test('BOSS 换营：墨鸦占优时不发动', () => {
  const e = fresh(89, { bossSkills: ['campSwap'] });
  setTurn(e, 'player');
  for (let c = 3; c <= 7; c++) put(e, 'ai', 5, c);
  put(e, 'ai', 9, 0);
  put(e, 'ai', 9, 6);
  e.state.campSwapCount = 1;
  for (let c = 1; c <= 4; c++) put(e, 'player', 9, c);
  e.place('player', 9, 5);
  assert.strictEqual(e.state.campSwapCount, 2);
  assert.strictEqual(e.state.campSwaps, 0);
  assert.strictEqual(e.state.campSwapSuppressed, 1);
  assert.strictEqual(e.getStone(9, 5).owner, 'player');
});

test('BOSS 换营：无该权能的关卡不计数', () => {
  const e = fresh(90);
  setTurn(e, 'player');
  for (let c = 1; c <= 4; c++) put(e, 'player', 2, c);
  e.place('player', 2, 5);
  assert.strictEqual(e.state.campSwapCount, 0);
  assert.strictEqual(e.state.campSwaps, 0);
});

console.log(`\n结果：${passed} 通过，${failed} 失败\n`);
if (failed) process.exit(1);
