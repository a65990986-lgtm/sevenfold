/* 七曜牌局 — 规则引擎（蓝条版）
 * 不依赖 DOM，可在浏览器与 Node 中运行。
 *
 * 核心规则：
 *   20×20 星盘，六子连珠；
 *   起手 7 张，每回合抽 2 张；
 *   蓝条上限 3，每回合开始回满；
 *   每回合出牌数量不限，只受蓝条限制；
 *   即时术式在落子前，延时秘式在落子后，位移术式会跳过落子。
 */
(function (root, factory) {
  const cards = (typeof module === 'object' && module.exports)
    ? require('./cards.js')
    : root.SEVENFOLD_CARDS;
  const lib = factory(cards);
  if (typeof module === 'object' && module.exports) module.exports = lib;
  root.SevenfoldEngine = lib.Engine;
  root.SEVENFOLD_RULES = lib.RULES;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (CARD_LIB) {
  'use strict';

  const CARDS = CARD_LIB.CARDS;
  const BASIC_CARDS = CARD_LIB.BASIC_CARDS || CARDS;
  const BY_ID = CARD_LIB.BY_ID;

  const RULES = {
    initialSize: 20,
    maxSize: 24,
    winLength: 6,
    startingHand: 7,
    drawPerTurn: 2,
    handLimit: 12,
    maxMana: 3,
    aegisRounds: 3,
    twinRounds: 3,
    fivefoldDelayRounds: 2,
    campSwapRun: 5
  };

  const DIRECTIONS = [
    [0, 1], [1, 0], [1, 1], [1, -1]
  ];
  const MOVE_DIRECTIONS = [
    [-1, 0], [1, 0], [0, -1], [0, 1],
    [-1, -1], [-1, 1], [1, -1], [1, 1]
  ];
  const SIDES = ['player', 'ai'];
  const opposite = side => (side === 'player' ? 'ai' : 'player');

  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0;
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function keyOf(r, c) { return r + ',' + c; }
  function parseKey(key) {
    const [r, c] = key.split(',').map(Number);
    return { r, c };
  }

  class Engine {
    constructor(options = {}) {
      this.rules = { ...RULES, ...(options.rules || {}) };
      this.listeners = [];
      this.newGame(options);
    }

    onEvent(fn) {
      this.listeners.push(fn);
      return () => {
        const i = this.listeners.indexOf(fn);
        if (i >= 0) this.listeners.splice(i, 1);
      };
    }

    emit(type, data = {}) {
      const event = { type, ...data };
      for (const fn of this.listeners) fn(event);
      return event;
    }

    newGame(options = {}) {
      this.seed = Number.isFinite(options.seed) ? options.seed : (Date.now() & 0xffffffff);
      this.rand = mulberry32(this.seed);
      this.uid = 0;
      this.state = {
        size: this.rules.initialSize,
        cells: this.makeBoard(this.rules.initialSize),
        current: 'player',
        phase: 'setup',
        status: 'playing',
        ply: 0,
        round: 1,
        cardsPlayedThisTurn: 0,
        placed: false,
        moved: false,
        skipPlace: false,
        winner: null,
        winLine: null,
        winReason: '',
        forced: null,
        seals: {},
        zones: [],
        doubleCells: {},
        lastMove: null,
        lastPlaced: { player: null, ai: null },
        advanced: !!options.advanced,
        bossSkills: [...(options.bossSkills || [])],
        playerRuns: new Set(),
        campSwapCount: 0,
        campSwaps: 0,
        campSwapSuppressed: 0,
        lastCampSwapPly: -1,
        players: {
          player: this.makePlayer(),
          ai: this.makePlayer()
        },
        stats: { stonesPlaced: 0, cardsPlayed: 0, captures: 0 }
      };
      this.dealOpeningHands();
      this.startTurn('player', { opening: true });
      this.emit('gameStart', { seed: this.seed });
      return this.state;
    }

    makeBoard(size) {
      return Array.from({ length: size }, () => Array(size).fill(null));
    }

    makePlayer() {
      return {
        hand: [],
        deck: [],
        discard: [],
        secrets: [],
        winTarget: this.rules.winLength,
        auras: [],
        silenced: false,
        mana: this.rules.maxMana,
        maxMana: this.rules.maxMana,
        scouted: null
      };
    }

    hasBossSkill(id) {
      return !!(this.state && Array.isArray(this.state.bossSkills) && this.state.bossSkills.includes(id));
    }

    bossMaxMana(side, round = this.state.round) {
      if (side === 'ai' && this.hasBossSkill('doubleCard') && round % 2 === 0) {
        return this.rules.maxMana + 1;
      }
      return this.rules.maxMana;
    }

    makeDeck() {
      const deck = [];
      for (const card of BASIC_CARDS) {
        const copies = card.copies ?? 2;
        for (let i = 0; i < copies; i++) {
          deck.push({ uid: 'c' + (++this.uid), id: card.id });
        }
      }
      return this.shuffle(deck);
    }

    shuffle(arr) {
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(this.rand() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    }

    dealOpeningHands() {
      for (const side of SIDES) {
        const p = this.state.players[side];
        p.deck = this.makeDeck();
        for (let i = 0; i < this.rules.startingHand; i++) {
          if (p.deck.length) p.hand.push(p.deck.pop());
        }
      }
    }

    get side() { return this.state.current; }
    get other() { return opposite(this.state.current); }

    inBounds(r, c) {
      return r >= 0 && c >= 0 && r < this.state.size && c < this.state.size;
    }

    cellAt(r, c) {
      return this.inBounds(r, c) ? this.state.cells[r][c] : null;
    }

    getStone(r, c) {
      const cell = this.cellAt(r, c);
      return cell && cell.owner ? cell : null;
    }

    setStone(r, c, stone) {
      this.state.cells[r][c] = stone;
    }

    sealAt(r, c) {
      const seal = this.state.seals[keyOf(r, c)];
      if (!seal) return null;
      if (seal.untilPly <= this.state.ply) {
        delete this.state.seals[keyOf(r, c)];
        return null;
      }
      return seal;
    }

    isSealed(r, c) {
      return !!this.sealAt(r, c);
    }

    cardById(id) {
      return BY_ID[id];
    }

    doubleCellAt(r, c) {
      const zone = this.state.doubleCells[keyOf(r, c)];
      if (!zone) return null;
      if (zone.expiresPly <= this.state.ply) {
        delete this.state.doubleCells[keyOf(r, c)];
        return null;
      }
      return zone;
    }

    isDoubleCell(r, c, owner = null) {
      const zone = this.doubleCellAt(r, c);
      if (!zone) return false;
      return !owner || zone.owner === owner;
    }

    stoneWeight(stone, r, c) {
      if (!stone) return 0;
      if (stone.doubled) return 2;
      const zone = this.doubleCellAt(r, c);
      return zone && zone.owner === stone.owner ? 2 : 1;
    }

    isStoneDoubled(r, c, stone = null) {
      const item = stone || this.getStone(r, c);
      if (!item) return false;
      return this.stoneWeight(item, r, c) >= 2;
    }

    draw(side, count = 1, meta = {}) {
      const p = this.state.players[side];
      const drawn = [];
      const ignoreLimit = !!meta.ignoreLimit;
      for (let i = 0; i < count; i++) {
        if (!p.deck.length) {
          if (!p.discard.length) break;
          p.deck = this.shuffle(p.discard.splice(0));
        }
        const card = p.deck.pop();
        if (!ignoreLimit && p.hand.length >= this.rules.handLimit) {
          p.discard.push(card);
          this.emit('cardBurned', { side, cardId: card.id });
          continue;
        }
        if (meta.temp) card.temp = true;
        p.hand.push(card);
        drawn.push(card);
      }
      if (drawn.length) {
        this.emit('draw', {
          side,
          cards: drawn.map(card => card.id),
          entries: drawn.map(card => ({ uid: card.uid, id: card.id, temp: !!card.temp })),
          count: drawn.length,
          temp: !!meta.temp,
          opening: !!meta.opening
        });
      }
      return drawn;
    }

    startTurn(side, meta = {}) {
      const s = this.state;
      if (s.status !== 'playing') return;
      if (this.boardFull()) {
        this.endInDraw();
        return;
      }
      s.current = side;
      s.phase = 'main';
      s.cardsPlayedThisTurn = 0;
      s.placed = false;
      s.moved = false;
      s.skipPlace = false;
      s.round = Math.floor(s.ply / 2) + 1;
      const p = s.players[side];
      p.maxMana = this.bossMaxMana(side, s.round);
      p.mana = p.maxMana;
      this.emit('manaRefilled', { side, mana: p.mana, maxMana: p.maxMana });
      this.checkForcedValidity();

      if (this.activateFivefold(side)) return;
      this.draw(side, this.rules.drawPerTurn, meta);
      this.activateForetell(side);
      this.emit('turnStart', {
        side,
        round: s.round,
        forced: s.forced ? { ...s.forced } : null,
        silenced: p.silenced,
        mana: p.mana,
        maxMana: p.maxMana,
        handLimit: this.rules.handLimit
      });
    }

    activateFivefold(side) {
      const s = this.state;
      const p = s.players[side];
      const secret = p.secrets.find(sec => sec.cardId === 'fivefold' && sec.activateRound <= s.round);
      if (!secret) return false;
      this.removeSecret(side, secret.uid, 'triggered');
      p.winTarget = 5;
      this.emit('fivefoldActivated', { side, target: 5, round: s.round });
      const win = this.resolveWins(side, 'fivefold');
      return !!win || s.status !== 'playing';
    }

    activateForetell(side) {
      const s = this.state;
      const p = s.players[side];
      const secrets = p.secrets.filter(sec => sec.cardId === 'foretell' && sec.activatePly <= s.ply);
      for (const secret of secrets) {
        this.removeSecret(side, secret.uid, 'triggered');
        const drawn = this.draw(side, 2, { temp: true, ignoreLimit: true });
        this.emit('foretell', { side, cards: drawn.map(card => card.id), entries: drawn.map(card => ({ uid: card.uid, id: card.id })) });
      }
    }

    checkForcedValidity() {
      const f = this.state.forced;
      if (!f) return;
      if (f.target !== this.state.current) return;
      const stone = this.getStone(f.r, f.c);
      if (!this.inBounds(f.r, f.c) || stone || this.isSealed(f.r, f.c)) {
        const old = { ...f };
        this.state.forced = null;
        this.emit('forceFizzle', { forced: old });
      }
    }

    getPlacementCells(side = this.state.current) {
      const cells = [];
      if (this.state.status !== 'playing' || this.state.current !== side || this.state.phase !== 'main') return cells;
      const forced = this.state.forced;
      if (forced && forced.target === side) {
        if (this.canPlace(side, forced.r, forced.c)) cells.push({ r: forced.r, c: forced.c });
        return cells;
      }
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          if (this.canPlace(side, r, c)) cells.push({ r, c });
        }
      }
      return cells;
    }

    canPlace(side, r, c) {
      const s = this.state;
      if (s.status !== 'playing' || s.current !== side || s.phase !== 'main') return false;
      if (!this.inBounds(r, c) || this.getStone(r, c)) return false;
      if (this.isSealed(r, c)) return false;
      const forced = s.forced;
      if (forced && forced.target === side && (forced.r !== r || forced.c !== c)) return false;
      return true;
    }

    canPlayCard(side, uid) {
      const s = this.state;
      const p = s.players[side];
      if (s.status !== 'playing') return { ok: false, reason: '对局已经结束' };
      if (s.current !== side) return { ok: false, reason: '还没轮到你' };
      const entry = p.hand.find(card => card.uid === uid);
      if (!entry) return { ok: false, reason: '手牌中没有这张牌' };
      const card = BY_ID[entry.id];
      if (!card) return { ok: false, reason: '未知卡牌' };
      if (card.final) return { ok: false, reason: '最终卡尚未解锁（完成 BOSS 关后开放）' };
      if (card.type === 'instant' && s.phase !== 'main') {
        return { ok: false, reason: '即时术式需在落子前发动' };
      }
      if (card.type === 'delayed' && s.phase !== 'post') {
        return { ok: false, reason: '延时秘式需在落子后布下' };
      }
      if (card.cost > p.mana) {
        return { ok: false, reason: `蓝量不足（需要 ${card.cost} 点，当前 ${p.mana}）` };
      }
      if ((entry.id === 'repel' || entry.id === 'shift') && s.forced && s.forced.target === side) {
        return { ok: false, reason: '被定身时不能以位移术式跳过落子' };
      }
      if (entry.id === 'expand' && s.size >= this.rules.maxSize) {
        return { ok: false, reason: '星盘已达到最大边界' };
      }
      if (entry.id === 'mirror') {
        if (p.secrets.some(sec => sec.cardId === 'mirror')) {
          return { ok: false, reason: '镜界已经有一张换影在等待触发' };
        }
        const anchorKey = s.lastPlaced[side];
        if (!anchorKey) return { ok: false, reason: '需要本回合刚落下的己方星子作为锚' };
        const anchor = parseKey(anchorKey);
        const anchorStone = this.getStone(anchor.r, anchor.c);
        if (!anchorStone || anchorStone.owner !== side) {
          return { ok: false, reason: '锚点星子已经消失' };
        }
      }
      if (entry.id === 'fivefold') {
        if (p.secrets.some(sec => sec.cardId === 'fivefold')) {
          return { ok: false, reason: '改命已在等待生效' };
        }
        if (p.winTarget <= 5) return { ok: false, reason: '胜利条件已经是五子' };
      }
      if (entry.id === 'silence' && s.players[opposite(side)].silenced) {
        return { ok: false, reason: '对方已被噤声，无需重复布下' };
      }
      if (card.target !== 'none' && this.getCardTargets(side, entry.id).length === 0) {
        return { ok: false, reason: '当前没有可用的目标' };
      }
      return { ok: true, card };
    }

    getCardTargets(side, cardId) {
      const card = BY_ID[cardId];
      if (!card || !card.target || card.target === 'none') return [];
      const s = this.state;
      const targets = [];
      for (let r = 0; r < s.size; r++) {
        for (let c = 0; c < s.size; c++) {
          const stone = this.getStone(r, c);
          if (card.target === 'cellEmpty') {
            if (!stone && !this.isSealed(r, c)) targets.push({ r, c });
          } else if (card.target === 'cellAny') {
            targets.push({ r, c });
          } else if (card.target === 'cellOwnOrEmpty') {
            if (!stone) {
              if (!this.isSealed(r, c)) targets.push({ r, c });
            } else if (stone.owner === side) {
              targets.push({ r, c });
            }
          } else if (card.target === 'stoneOwn') {
            if (stone && stone.owner === side && !(stone.shieldUntil > s.ply)) targets.push({ r, c });
          } else if (card.target === 'moveEnemy') {
            if (stone && stone.owner !== side && !(stone.shieldUntil > s.ply) && this.getMoveDestinations(r, c).length) {
              targets.push({ r, c });
            }
          } else if (card.target === 'moveOwn') {
            if (stone && stone.owner === side && this.getMoveDestinations(r, c).length) {
              targets.push({ r, c });
            }
          }
        }
      }
      return targets;
    }

    getMoveDestinations(r, c) {
      const dests = [];
      if (!this.inBounds(r, c)) return dests;
      for (const [dr, dc] of MOVE_DIRECTIONS) {
        const nr = r + dr;
        const nc = c + dc;
        if (this.inBounds(nr, nc) && !this.getStone(nr, nc) && !this.isSealed(nr, nc)) {
          dests.push({ r: nr, c: nc, dr, dc });
        }
      }
      return dests;
    }

    validatePayload(cardId, side, payload = {}) {
      const card = BY_ID[cardId];
      if (!card) return { ok: false, reason: '未知卡牌' };
      const target = card.target;
      if (target === 'none') return { ok: true };
      if (target === 'cellEmpty' || target === 'cellAny' || target === 'cellOwnOrEmpty') {
        const { r, c } = payload;
        if (!this.inBounds(r, c)) return { ok: false, reason: '目标不在星盘内' };
        const stone = this.getStone(r, c);
        if (target === 'cellEmpty' && stone) return { ok: false, reason: '该格已有星子' };
        if (target === 'cellEmpty' && this.isSealed(r, c)) return { ok: false, reason: '该格已被封禁' };
        if (target === 'cellOwnOrEmpty') {
          if (stone && stone.owner !== side) return { ok: false, reason: '只能选择空格或己方星子' };
          if (!stone && this.isSealed(r, c)) return { ok: false, reason: '该格已被封禁' };
        }
        return { ok: true };
      }
      if (target === 'stoneOwn') {
        const stone = this.getStone(payload.r, payload.c);
        if (!stone || stone.owner !== side) return { ok: false, reason: '必须选择己方星子' };
        if (stone.shieldUntil > this.state.ply) return { ok: false, reason: '该星子已在不灭状态' };
        return { ok: true };
      }
      if (target === 'moveEnemy' || target === 'moveOwn') {
        const from = payload.from || payload;
        const to = payload.to;
        const stone = this.getStone(from.r, from.c);
        if (!stone) return { ok: false, reason: '起点没有星子' };
        if (target === 'moveEnemy' && stone.owner === side) return { ok: false, reason: '必须选择敌方星子' };
        if (target === 'moveOwn' && stone.owner !== side) return { ok: false, reason: '必须选择己方星子' };
        if (target === 'moveEnemy' && stone.shieldUntil > this.state.ply) {
          return { ok: false, reason: '金身庇护，无法推动' };
        }
        if (!to) return { ok: false, reason: '请选择移动方向' };
        const dr = to.r - from.r;
        const dc = to.c - from.c;
        if (Math.abs(dr) > 1 || Math.abs(dc) > 1 || (dr === 0 && dc === 0)) {
          return { ok: false, reason: '只能向周围八格移动一格' };
        }
        if (!this.inBounds(to.r, to.c) || this.getStone(to.r, to.c)) return { ok: false, reason: '目标格不可进入' };
        if (this.isSealed(to.r, to.c)) return { ok: false, reason: '目标格已被封禁' };
        return { ok: true };
      }
      return { ok: false, reason: '目标类型未知' };
    }

    playCard(side, uid, payload = {}) {
      const check = this.canPlayCard(side, uid);
      if (!check.ok) return check;
      const card = check.card;
      const targetCheck = this.validatePayload(card.id, side, payload);
      if (!targetCheck.ok) return targetCheck;

      const s = this.state;
      const p = s.players[side];
      const idx = p.hand.findIndex(entry => entry.uid === uid);
      const [entry] = p.hand.splice(idx, 1);
      if (entry.temp) this.emit('tempCardConsumed', { side, cardId: entry.id });
      else p.discard.push(entry);
      const cost = Math.min(card.cost || 0, p.mana);
      p.mana -= cost;
      s.cardsPlayedThisTurn++;
      s.stats.cardsPlayed++;
      this.emit('manaSpent', { side, cost, mana: p.mana, cardId: card.id });

      if (p.silenced) {
        p.silenced = false;
        const opp = s.players[opposite(side)];
        const secret = opp.secrets.find(sec => sec.cardId === 'silence');
        if (secret) this.removeSecret(opposite(side), secret.uid, 'triggered');
        this.emit('cardNullified', { side, cardId: card.id, cost, mana: p.mana });
        return { ok: true, nullified: true, card, cost, mana: p.mana };
      }

      if (card.type === 'instant') {
        this.emit('cardPlayed', { side, cardId: card.id, cost, mana: p.mana });
      }

      let result = { ok: true, card, cost, mana: p.mana };
      switch (card.id) {
        case 'sealOrtho':
        case 'sealDiag':
        case 'ruin':
          p.auras.push({ type: card.id, createdPly: s.ply, cost });
          result.auras = p.auras;
          this.emit('auraAdded', { side, aura: p.auras[p.auras.length - 1], auras: p.auras });
          break;
        case 'expand':
          result = { ...result, ...this.expandBoard(side) };
          break;
        case 'twin': {
          const zone = this.setDoubleCell(side, payload.r, payload.c);
          result.doubleCell = zone;
          const win = this.resolveWins(side, 'twin');
          if (win) result.win = win;
          if (!win && side === 'player') {
            const swap = this.maybeCampSwap('player');
            if (swap) {
              result.campSwap = swap;
              if (swap.win) result.win = swap.win;
            }
          }
          break;
        }
        case 'repel':
          result = { ...result, ...this.applyMove(side, opposite(side), payload, card.id) };
          break;
        case 'shift':
          result = { ...result, ...this.applyMove(side, side, payload, card.id) };
          break;
        case 'scout': {
          const target = s.players[opposite(side)];
          const seen = target.hand.map(cardEntry => ({
            uid: cardEntry.uid,
            id: cardEntry.id,
            temp: !!cardEntry.temp
          }));
          p.scouted = { cards: seen, atPly: s.ply, atRound: s.round };
          result.scouted = seen;
          this.emit('scouted', { side, target: opposite(side), cards: seen });
          break;
        }
        case 'aegis': {
          const stone = this.getStone(payload.r, payload.c);
          stone.shieldUntil = s.ply + this.rules.aegisRounds * 2;
          const secret = this.addSecret(side, 'aegis', {
            anchor: { r: payload.r, c: payload.c },
            targetUid: stone.uid,
            expiresPly: stone.shieldUntil
          });
          result.secret = secret;
          break;
        }
        case 'mirror': {
          const anchor = parseKey(s.lastPlaced[side]);
          const secret = this.addSecret(side, 'mirror', {
            anchor,
            expiresPly: s.ply + 2
          });
          result.secret = secret;
          break;
        }
        case 'fivefold':
          result.secret = this.addSecret(side, 'fivefold', {
            activateRound: s.round + this.rules.fivefoldDelayRounds,
            expiresPly: null
          });
          break;
        case 'silence': {
          const target = s.players[opposite(side)];
          target.silenced = true;
          result.secret = this.addSecret(side, 'silence', { expiresPly: s.ply + 2 });
          break;
        }
        case 'subvert': {
          const secret = this.addSecret(side, 'subvert', {
            center: { r: payload.r, c: payload.c },
            expiresPly: s.ply + 2
          });
          const zone = {
            owner: side,
            center: { r: payload.r, c: payload.c },
            secretUid: secret.uid,
            expiresPly: s.ply + 2
          };
          s.zones.push(zone);
          result.zone = zone;
          result.secret = secret;
          break;
        }
        case 'foretell':
          result.secret = this.addSecret(side, 'foretell', {
            activatePly: s.ply + 2,
            expiresPly: null
          });
          break;
        case 'finalPin':
          s.forced = {
            target: opposite(side),
            r: payload.r,
            c: payload.c,
            by: side,
            createdPly: s.ply,
            expiresPly: s.ply + 2
          };
          result.forced = { ...s.forced };
          break;
        case 'finalConvert':
          this.convertAll(side);
          result.win = this.resolveWins(side, 'final');
          break;
        default:
          break;
      }

      if (card.type === 'delayed') {
        this.emit('secretSet', { side, cardId: card.id, secret: result.secret || null, cost, mana: p.mana });
      }
      return result;
    }

    setDoubleCell(side, r, c) {
      const s = this.state;
      const zone = {
        owner: side,
        r,
        c,
        createdPly: s.ply,
        createdRound: s.round,
        expiresPly: s.ply + this.rules.twinRounds * 2
      };
      s.doubleCells[keyOf(r, c)] = zone;
      this.emit('doubleCellSet', { side, zone: { ...zone } });
      return zone;
    }

    convertAll(side) {
      const s = this.state;
      for (let r = 0; r < s.size; r++) {
        for (let c = 0; c < s.size; c++) {
          const stone = this.getStone(r, c);
          if (!stone) continue;
          stone.owner = opposite(stone.owner);
          stone.convertedAll = true;
        }
      }
      this.emit('allConverted', { side });
    }

    applyMove(side, owner, payload, cardId) {
      const from = payload.from || payload;
      const to = payload.to;
      const stone = this.getStone(from.r, from.c);
      this.setStone(from.r, from.c, null);
      this.setStone(to.r, to.c, stone);
      stone.movedPly = this.state.ply;
      this.state.lastPlaced[owner] = keyOf(to.r, to.c);
      this.state.lastMove = { r: to.r, c: to.c, side: owner, type: 'move' };
      this.state.skipPlace = true;
      this.state.moved = true;
      this.state.phase = 'post';
      this.emit('stoneMoved', {
        by: side,
        owner,
        cardId,
        from: { r: from.r, c: from.c },
        to: { r: to.r, c: to.c },
        stone
      });
      const win = this.resolveWins(owner, 'move');
      if (win) return { moved: true, win };
      const swap = this.maybeCampSwap('player');
      if (swap) {
        const result = { moved: true, campSwap: swap, from: { r: from.r, c: from.c }, to: { r: to.r, c: to.c } };
        if (swap.win) result.win = swap.win;
        return result;
      }
      if (this.boardFull()) {
        this.endInDraw();
        return { moved: true, draw: true };
      }
      return { moved: true, from: { r: from.r, c: from.c }, to: { r: to.r, c: to.c } };
    }

    /* ---------------- BOSS 权能：换营 ---------------- */

    collectRuns(side, minLength) {
      const runs = new Set();
      const s = this.state;
      const n = s.size;
      for (let r = 0; r < n; r++) {
        for (let c = 0; c < n; c++) {
          const stone = this.getStone(r, c);
          if (!stone || stone.owner !== side) continue;
          for (let d = 0; d < DIRECTIONS.length; d++) {
            const [dr, dc] = DIRECTIONS[d];
            const prev = this.getStone(r - dr, c - dc);
            if (prev && prev.owner === side) continue;
            let total = 0;
            let rr = r;
            let cc = c;
            while (this.inBounds(rr, cc)) {
              const item = this.getStone(rr, cc);
              if (!item || item.owner !== side) break;
              total += this.stoneWeight(item, rr, cc);
              rr += dr;
              cc += dc;
            }
            if (total >= minLength) runs.add(d + ':' + r + ',' + c);
          }
        }
      }
      return runs;
    }

    runScore(total, open, target) {
      const gap = target - total;
      if (gap <= 0) return 1e8;
      const table = [0, 4e6, 8e5, 5e4, 1.5e3, 90, 8];
      const base = table[Math.min(gap, 6)];
      const mult = open >= 2 ? 1 : open === 1 ? 0.16 : 0.03;
      return base * mult * (1 + 0.06 * total);
    }

    positionScore(side) {
      const target = this.state.players[side].winTarget;
      const n = this.state.size;
      let score = 0;
      for (let r = 0; r < n; r++) {
        for (let c = 0; c < n; c++) {
          const stone = this.getStone(r, c);
          if (!stone || stone.owner !== side) continue;
          for (const [dr, dc] of DIRECTIONS) {
            const prev = this.getStone(r - dr, c - dc);
            if (prev && prev.owner === side) continue;
            let total = 0;
            let rr = r;
            let cc = c;
            while (this.inBounds(rr, cc)) {
              const item = this.getStone(rr, cc);
              if (!item || item.owner !== side) break;
              total += this.stoneWeight(item, rr, cc);
              rr += dr;
              cc += dc;
            }
            let open = 0;
            if (this.inBounds(rr, cc) && !this.getStone(rr, cc)) open += 1;
            if (this.inBounds(r - dr, c - dc) && !this.getStone(r - dr, c - dc)) open += 1;
            score += this.runScore(total, open, target);
          }
        }
      }
      return score;
    }

    maybeCampSwap(side) {
      const s = this.state;
      if (side !== 'player') return null;
      if (!this.hasBossSkill('campSwap')) return null;
      if (s.status !== 'playing') return null;
      let added = 0;
      for (const key of this.collectRuns('player', this.rules.campSwapRun || 5)) {
        if (!s.playerRuns.has(key)) {
          s.playerRuns.add(key);
          added += 1;
        }
      }
      if (!added) return null;
      s.campSwapCount += added;
      if (s.campSwapCount % 2 !== 0) return null;
      const aiScore = this.positionScore('ai');
      const playerScore = this.positionScore('player');
      if (aiScore > playerScore) {
        s.campSwapSuppressed += 1;
        this.emit('campSwapSuppressed', { aiScore, playerScore, count: s.campSwapCount });
        return null;
      }
      return this.swapCamps({ aiScore, playerScore });
    }

    swapCamps(meta = {}) {
      const s = this.state;
      if (s.status !== 'playing') return null;
      let flipped = 0;
      for (let r = 0; r < s.size; r++) {
        for (let c = 0; c < s.size; c++) {
          const stone = s.cells[r][c];
          if (!stone || !stone.owner) continue;
          stone.owner = opposite(stone.owner);
          flipped += 1;
        }
      }
      s.lastPlaced = { player: s.lastPlaced.ai, ai: s.lastPlaced.player };
      if (s.lastMove && s.lastMove.side) s.lastMove.side = opposite(s.lastMove.side);
      if (s.lastMove && s.lastMove.stoneUid) {
        const placed = this.findStoneByUid(s.lastMove.stoneUid);
        if (placed) s.lastMove.side = placed.owner;
      }
      s.campSwaps += 1;
      s.lastCampSwapPly = s.ply;
      this.emit('campsSwapped', { flipped, ...meta });
      const win = this.resolveWins('ai', 'campswap');
      return { flipped, win, ...meta };
    }

    findStoneByUid(uid) {
      const s = this.state;
      for (let r = 0; r < s.size; r++) {
        for (let c = 0; c < s.size; c++) {
          if (s.cells[r][c] && s.cells[r][c].uid === uid) return s.cells[r][c];
        }
      }
      return null;
    }

    place(side, r, c) {
      const s = this.state;
      if (s.status !== 'playing') return { ok: false, reason: '对局已经结束' };
      if (s.current !== side) return { ok: false, reason: '还没轮到你' };
      if (s.phase !== 'main') return { ok: false, reason: '现在不是落子阶段' };
      if (!this.canPlace(side, r, c)) return { ok: false, reason: this.placementError(side, r, c) };

      const p = s.players[side];
      const auras = p.auras.slice();
      const stone = {
        uid: 's' + (++this.uid),
        owner: side,
        doubled: false,
        shieldUntil: 0,
        placedPly: s.ply
      };
      this.setStone(r, c, stone);
      p.auras = [];
      s.stats.stonesPlaced++;
      s.lastPlaced[side] = keyOf(r, c);
      s.lastMove = { r, c, side, type: 'place', stoneUid: stone.uid };
      if (s.forced && s.forced.target === side) s.forced = null;
      s.placed = true;
      s.phase = 'post';

      const result = { ok: true, stone, r, c, effects: [], auras };
      this.emit('stonePlaced', { side, r, c, stone, auras });

      const hasRuin = auras.some(aura => aura.type === 'ruin');
      const sealAuras = auras.filter(aura => aura.type === 'sealOrtho' || aura.type === 'sealDiag');
      for (const aura of sealAuras) {
        result.effects.push(this.applySealAura(r, c, side, aura.type));
      }
      if (hasRuin) {
        result.effects.push(this.detonate(r, c, side));
        s.lastPlaced[side] = null;
      } else {
        const conversion = this.triggerSubvert(side, r, c, stone);
        if (conversion) result.effects.push(conversion);
        const mirror = this.triggerMirror(side, r, c);
        if (mirror) result.effects.push(mirror);
      }

      const prefer = result.effects.find(e => e.type === 'subvert')?.owner || side;
      const win = this.resolveWins(prefer, 'place');
      if (win) result.win = win;
      if (!win) {
        const swap = this.maybeCampSwap(side);
        if (swap) {
          result.campSwap = swap;
          if (swap.win) result.win = swap.win;
        }
      }
      if (!result.win && this.state.status === 'playing' && this.boardFull()) {
        this.endInDraw();
        result.draw = true;
      }
      return result;
    }

    placementError(side, r, c) {
      if (!this.inBounds(r, c)) return '该格不在星盘内';
      if (this.getStone(r, c)) return '该格已有星子';
      if (this.isSealed(r, c)) return '该格已被封禁';
      const forced = this.state.forced;
      if (forced && forced.target === side) return '定身要求落在标记格';
      return '现在不能落子';
    }

    applySealAura(r, c, side, auraType) {
      const dirs = auraType === 'sealOrtho'
        ? [[-1, 0], [1, 0], [0, -1], [0, 1]]
        : [[-1, -1], [-1, 1], [1, -1], [1, 1]];
      const cells = [];
      for (const [dr, dc] of dirs) {
        const nr = r + dr;
        const nc = c + dc;
        if (!this.inBounds(nr, nc)) continue;
        const untilPly = this.state.ply + 2;
        this.state.seals[keyOf(nr, nc)] = { by: side, untilPly, source: auraType };
        cells.push({ r: nr, c: nc });
      }
      this.emit('sealed', { side, cells, source: auraType });
      return { type: 'seal', owner: side, cells, source: auraType };
    }

    detonate(r, c, owner) {
      const removed = [];
      const shielded = [];
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const nr = r + dr;
          const nc = c + dc;
          if (!this.inBounds(nr, nc)) continue;
          const stone = this.getStone(nr, nc);
          if (!stone) continue;
          if (stone.owner !== owner && stone.shieldUntil > this.state.ply) {
            shielded.push({ r: nr, c: nc, owner: stone.owner });
            continue;
          }
          removed.push({ r: nr, c: nc, owner: stone.owner, doubled: this.isStoneDoubled(nr, nc, stone) });
          this.setStone(nr, nc, null);
          this.state.stats.captures++;
        }
      }
      this.emit('detonated', { owner, center: { r, c }, removed, shielded });
      return { type: 'burst', owner, center: { r, c }, removed, shielded };
    }

    triggerSubvert(side, r, c, stone) {
      const zone = this.state.zones.find(z => z.owner !== side && z.expiresPly > this.state.ply && this.inZone(z, r, c));
      if (!zone) return null;
      const previousOwner = stone.owner;
      stone.owner = zone.owner;
      stone.convertedFrom = previousOwner;
      this.removeZone(zone, 'triggered');
      const opp = this.state.players[zone.owner];
      const sec = opp.secrets.find(item => item.uid === zone.secretUid);
      if (sec) this.removeSecret(zone.owner, sec.uid, 'triggered');
      this.state.lastMove.stoneUid = stone.uid;
      this.emit('subverted', {
        owner: zone.owner,
        previousOwner,
        at: { r, c },
        stone
      });
      return { type: 'subvert', owner: zone.owner, previousOwner, at: { r, c } };
    }

    triggerMirror(side, r, c) {
      const oppSide = opposite(side);
      const p = this.state.players[oppSide];
      const secret = p.secrets.find(sec => sec.cardId === 'mirror' && sec.expiresPly > this.state.ply);
      if (!secret) return null;
      const anchor = secret.anchor;
      const anchorStone = this.getStone(anchor.r, anchor.c);
      const newStone = this.getStone(r, c);
      if (!anchorStone || !newStone) return null;
      if (anchorStone.owner !== oppSide) return null;
      if (anchorStone.shieldUntil > this.state.ply) {
        this.removeSecret(oppSide, secret.uid, 'blocked');
        this.emit('mirrorBlocked', { owner: oppSide, anchor });
        return { type: 'mirrorBlocked', owner: oppSide };
      }
      this.setStone(anchor.r, anchor.c, newStone);
      this.setStone(r, c, anchorStone);
      this.state.lastPlaced[oppSide] = keyOf(r, c);
      this.state.lastPlaced[side] = keyOf(anchor.r, anchor.c);
      this.state.lastMove = { r: anchor.r, c: anchor.c, side, type: 'mirror' };
      this.removeSecret(oppSide, secret.uid, 'triggered');
      this.emit('mirrored', {
        owner: oppSide,
        anchor,
        placed: { r, c },
        side
      });
      return { type: 'mirror', owner: oppSide, anchor, placed: { r, c } };
    }

    inZone(zone, r, c) {
      return Math.abs(zone.center.r - r) <= 1 && Math.abs(zone.center.c - c) <= 1;
    }

    removeZone(zone, status) {
      const idx = this.state.zones.indexOf(zone);
      if (idx >= 0) this.state.zones.splice(idx, 1);
      this.emit('zoneRemoved', { zone, status });
    }

    addSecret(side, cardId, extra = {}) {
      const secret = {
        uid: 'x' + (++this.uid),
        cardId,
        createdPly: this.state.ply,
        createdRound: this.state.round,
        ...extra
      };
      this.state.players[side].secrets.push(secret);
      return secret;
    }

    removeSecret(side, uid, status = 'expired') {
      const p = this.state.players[side];
      const idx = p.secrets.findIndex(sec => sec.uid === uid);
      if (idx < 0) return null;
      const [secret] = p.secrets.splice(idx, 1);
      if (secret.cardId === 'silence' && status === 'expired') {
        this.state.players[opposite(side)].silenced = false;
      }
      this.emit('secretRemoved', { side, secret, status });
      return secret;
    }

    expireTimedEffects() {
      const now = this.state.ply;
      for (const key of Object.keys(this.state.doubleCells)) {
        const zone = this.state.doubleCells[key];
        if (zone.expiresPly <= now) {
          delete this.state.doubleCells[key];
          this.emit('doubleCellExpired', { zone });
        }
      }
      for (const side of SIDES) {
        const p = this.state.players[side];
        for (const secret of [...p.secrets]) {
          if (secret.expiresPly == null) continue;
          if (now < secret.expiresPly) continue;
          if (secret.cardId === 'subvert') {
            const zone = this.state.zones.find(z => z.secretUid === secret.uid);
            if (zone) this.removeZone(zone, 'expired');
          }
          this.removeSecret(side, secret.uid, 'expired');
          this.emit('secretExpired', { side, secret });
        }
      }
    }

    destroyTempCards(side) {
      const s = this.state;
      const p = s.players[side];
      const removed = [];
      for (let i = p.hand.length - 1; i >= 0; i--) {
        if (p.hand[i].temp) {
          removed.push(p.hand[i]);
          p.hand.splice(i, 1);
        }
      }
      if (removed.length) {
        this.emit('tempCardsDestroyed', { side, cards: removed.map(card => card.id), entries: removed });
      }
    }

    endTurn(side) {
      const s = this.state;
      if (s.status !== 'playing') return { ok: false, reason: '对局已经结束' };
      if (s.current !== side) return { ok: false, reason: '还没轮到你' };
      if (s.phase !== 'post') return { ok: false, reason: '请先落子或完成位移' };
      this.destroyTempCards(side);
      if (s.forced && s.forced.target === side) s.forced = null;
      if (s.players[side].silenced) {
        s.players[side].silenced = false;
        const opp = s.players[opposite(side)];
        const silentSecret = opp.secrets.find(sec => sec.cardId === 'silence');
        if (silentSecret) this.removeSecret(opposite(side), silentSecret.uid, 'expired');
      }
      s.ply++;
      s.round = Math.floor(s.ply / 2) + 1;
      this.expireTimedEffects();
      const next = opposite(side);
      this.emit('turnEnd', { side, next, round: s.round });
      this.startTurn(next);
      return { ok: true, next };
    }

    resolveWins(prefer, reason = '') {
      const order = prefer ? [prefer, opposite(prefer)] : [...SIDES];
      for (const side of order) {
        const win = this.findWin(side);
        if (win) {
          this.finishGame(side, win, reason);
          return win;
        }
      }
      return null;
    }

    findWin(side) {
      const s = this.state;
      const target = s.players[side].winTarget;
      for (let r = 0; r < s.size; r++) {
        for (let c = 0; c < s.size; c++) {
          const stone = this.getStone(r, c);
          if (!stone || stone.owner !== side) continue;
          for (const [dr, dc] of DIRECTIONS) {
            const pr = r - dr;
            const pc = c - dc;
            const prev = this.getStone(pr, pc);
            if (prev && prev.owner === side) continue;
            let weight = 0;
            const cells = [];
            let nr = r;
            let nc = c;
            while (this.inBounds(nr, nc)) {
              const item = this.getStone(nr, nc);
              if (!item || item.owner !== side) break;
              weight += this.stoneWeight(item, nr, nc);
              cells.push({ r: nr, c: nc });
              if (weight >= target) {
                return { side, cells, weight, target, dir: [dr, dc] };
              }
              nr += dr;
              nc += dc;
            }
          }
        }
      }
      return null;
    }

    wouldWinAt(r, c, side, weight = 1) {
      if (!this.inBounds(r, c) || this.getStone(r, c)) return false;
      const target = this.state.players[side].winTarget;
      const zone = this.doubleCellAt(r, c);
      const centerWeight = Math.max(weight, zone && zone.owner === side ? 2 : 1);
      for (const [dr, dc] of DIRECTIONS) {
        let total = centerWeight;
        for (const sign of [-1, 1]) {
          let nr = r + dr * sign;
          let nc = c + dc * sign;
          while (this.inBounds(nr, nc)) {
            const stone = this.getStone(nr, nc);
            if (!stone || stone.owner !== side) break;
            total += this.stoneWeight(stone, nr, nc);
            nr += dr * sign;
            nc += dc * sign;
          }
        }
        if (total >= target) return true;
      }
      return false;
    }

    lineInfoAt(r, c, side, weight = 1) {
      const target = this.state.players[side].winTarget;
      const zone = this.doubleCellAt(r, c);
      const centerWeight = Math.max(weight, zone && zone.owner === side ? 2 : 1);
      let best = null;
      for (const [dr, dc] of DIRECTIONS) {
        let total = centerWeight;
        let openA = false;
        let openB = false;
        let lenA = 0;
        let lenB = 0;
        for (const sign of [-1, 1]) {
          let nr = r + dr * sign;
          let nc = c + dc * sign;
          let count = 0;
          while (this.inBounds(nr, nc)) {
            const stone = this.getStone(nr, nc);
            if (stone && stone.owner === side) {
              total += this.stoneWeight(stone, nr, nc);
              count++;
              nr += dr * sign;
              nc += dc * sign;
              continue;
            }
            if (!stone) {
              if (sign === -1) openA = true; else openB = true;
            }
            break;
          }
          if (sign === -1) lenA = count; else lenB = count;
        }
        const info = {
          total,
          openA,
          openB,
          lenA,
          lenB,
          open: (openA ? 1 : 0) + (openB ? 1 : 0),
          target,
          dir: [dr, dc]
        };
        if (!best || info.total > best.total || (info.total === best.total && info.open > best.open)) best = info;
      }
      return best || { total: centerWeight, open: 0, lenA: 0, lenB: 0, target, dir: [0, 1] };
    }

    getWinningCells(side, weight = 1) {
      const out = [];
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          if (!this.getStone(r, c) && !this.isSealed(r, c) && this.wouldWinAt(r, c, side, weight)) {
            out.push({ r, c });
          }
        }
      }
      return out;
    }

    boardFull() {
      for (let r = 0; r < this.state.size; r++) {
        for (let c = 0; c < this.state.size; c++) {
          if (!this.getStone(r, c)) return false;
        }
      }
      return true;
    }

    finishGame(winner, win, reason) {
      const s = this.state;
      if (s.status !== 'playing') return;
      s.status = 'over';
      s.winner = winner;
      s.winLine = win;
      s.winReason = reason;
      s.phase = 'over';
      this.emit('gameOver', { winner, win, reason });
    }

    endInDraw() {
      const s = this.state;
      if (s.status !== 'playing') return;
      s.status = 'draw';
      s.winner = null;
      s.phase = 'over';
      this.emit('gameOver', { winner: null, draw: true });
    }

    expandBoard(side) {
      const s = this.state;
      if (s.size >= this.rules.maxSize) return { ok: false, reason: '星盘已达到最大边界' };
      const oldSize = s.size;
      const newSize = Math.min(oldSize + 2, this.rules.maxSize);
      const next = this.makeBoard(newSize);
      for (let r = 0; r < oldSize; r++) {
        for (let c = 0; c < oldSize; c++) {
          if (s.cells[r][c]) next[r + 1][c + 1] = s.cells[r][c];
        }
      }
      s.cells = next;
      s.size = newSize;
      const seals = {};
      for (const [key, value] of Object.entries(s.seals)) {
        const { r, c } = parseKey(key);
        seals[keyOf(r + 1, c + 1)] = value;
      }
      s.seals = seals;
      const doubles = {};
      for (const [key, value] of Object.entries(s.doubleCells)) {
        const { r, c } = parseKey(key);
        doubles[keyOf(r + 1, c + 1)] = { ...value, r: value.r + 1, c: value.c + 1 };
      }
      s.doubleCells = doubles;
      const runs = new Set();
      for (const key of s.playerRuns) {
        const sep = key.indexOf(':');
        const dir = key.slice(0, sep);
        const { r, c } = parseKey(key.slice(sep + 1));
        runs.add(dir + ':' + (r + 1) + ',' + (c + 1));
      }
      s.playerRuns = runs;
      if (s.forced) {
        s.forced.r += 1;
        s.forced.c += 1;
      }
      for (const zone of s.zones) {
        zone.center.r += 1;
        zone.center.c += 1;
      }
      for (const p of Object.values(s.players)) {
        for (const secret of p.secrets) {
          if (secret.anchor) {
            secret.anchor.r += 1;
            secret.anchor.c += 1;
          }
          if (secret.center) {
            secret.center.r += 1;
            secret.center.c += 1;
          }
        }
      }
      for (const owner of SIDES) {
        if (s.lastPlaced[owner]) {
          const { r, c } = parseKey(s.lastPlaced[owner]);
          s.lastPlaced[owner] = keyOf(r + 1, c + 1);
        }
      }
      if (s.lastMove) {
        s.lastMove.r += 1;
        s.lastMove.c += 1;
      }
      if (s.winLine) {
        s.winLine.cells = s.winLine.cells.map(cell => ({ r: cell.r + 1, c: cell.c + 1 }));
      }
      s.phase = 'main';
      this.emit('boardExpanded', { side, from: oldSize, to: newSize });
      return { expanded: true, from: oldSize, to: newSize };
    }

    getPublicState() {
      const s = this.state;
      return {
        size: s.size,
        cells: s.cells,
        current: s.current,
        phase: s.phase,
        status: s.status,
        ply: s.ply,
        round: s.round,
        forced: s.forced ? { ...s.forced } : null,
        seals: { ...s.seals },
        doubleCells: { ...s.doubleCells },
        zones: s.zones.filter(z => z.owner === 'ai').map(z => ({ ...z, center: { ...z.center } })),
        lastPlaced: { ...s.lastPlaced },
        winTargets: { player: s.players.player.winTarget, ai: s.players.ai.winTarget },
        hands: { player: s.players.player.hand.length, ai: s.players.ai.hand.length },
        mana: { player: s.players.player.mana, ai: s.players.ai.mana },
        silenced: s.players.ai.silenced,
        aiSecrets: s.players.ai.secrets.map(sec => ({ ...sec })),
        aiAuras: s.players.ai.auras.map(aura => ({ ...aura })),
        bossSkills: [...(s.bossSkills || [])],
        campSwapCount: s.campSwapCount || 0,
        campSwaps: s.campSwaps || 0,
        campSwapSuppressed: s.campSwapSuppressed || 0,
        maxMana: { player: s.players.player.maxMana, ai: s.players.ai.maxMana }
      };
    }
  }

  return { Engine, RULES, DIRECTIONS, MOVE_DIRECTIONS, opposite };
});
